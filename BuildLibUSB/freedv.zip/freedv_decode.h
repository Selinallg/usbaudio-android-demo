#ifndef FREEDV_DECODE_H
#define FREEDV_DECODE_H

/* Setup is done once. */
int freedv_create(void);

#endif
